// App base de Gastos OCR
// Reemplaza la URL del Web App de Google Apps Script:
const WEB_APP_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';

console.log('App OCR lista. Agrega tu lógica aquí.');
