# Gastos OCR (Versión Base)
Generado: 2025-10-25

1. Abre Code.gs en Google Apps Script y reemplaza `YOUR_SHEET_ID_HERE` con el ID de tu Google Sheet.
2. Despliega el Web App (con acceso Anyone with link) y copia la URL.
3. En app.js, reemplaza `YOUR_APPS_SCRIPT_WEB_APP_URL` por esa URL.
4. Sube estos archivos a GitHub y publica con GitHub Pages.
5. Abre la URL desde Safari en iPhone y agrega a pantalla de inicio.
